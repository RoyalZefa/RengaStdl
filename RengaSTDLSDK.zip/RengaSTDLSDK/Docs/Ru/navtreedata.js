/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Renga STDL", "index.html", [
    [ "О Renga STDL", "index.html", "index" ],
    [ "История изменений", "changelog.html", [
      [ "Версия 3.0", "changelog.html#v3_0", null ],
      [ "Версия 2.0", "changelog.html#v2_0", null ],
      [ "Версия 1.1", "changelog.html#v1_1", null ],
      [ "Версия 1.0", "changelog.html#autotoc_md4", null ]
    ] ],
    [ "Необходимые инструменты", "required_tools.html", [
      [ "Редактор кода", "required_tools.html#autotoc_md5", null ],
      [ "Комплект разработчика шаблона стиля", "required_tools.html#autotoc_md6", null ]
    ] ],
    [ "Структура шаблона стиля", "style_template_structure.html", "style_template_structure" ],
    [ "Сборка шаблона стиля", "style_template_building.html", [
      [ "Формат командной строки", "style_template_building.html#autotoc_md21", null ],
      [ "Использование RstBuilder", "style_template_building.html#autotoc_md22", [
        [ "Проверка входных файлов", "style_template_building.html#autotoc_md23", null ]
      ] ],
      [ "Интеграция в Visual Studio Code", "style_template_building.html#autotoc_md24", null ]
    ] ],
    [ "Примеры создания шаблонов стилей", "example_of_style_template_creation.html", "example_of_style_template_creation" ],
    [ "Тестирование и отладка", "testing_and_debugging.html", [
      [ "Обработка ошибок возникающих во время выполнения скрипта", "testing_and_debugging.html#autotoc_md40", null ],
      [ "Использование функции print() для отладки:", "testing_and_debugging.html#autotoc_md41", null ],
      [ "Получение дополнительной информации с помощью функции tostring()", "testing_and_debugging.html#autotoc_md42", null ]
    ] ],
    [ "Как составить символьное выражение", "expressions.html", null ],
    [ "Style Template API", "topics.html", "topics" ],
    [ "Пространства имен", "namespaces.html", [
      [ "Пространства имен", "namespaces.html", "namespaces_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"changelog.html",
"group___three-dimensional.html#ga724990d0a1c91533f39f870d058993f7"
];

var SYNCONMSG = 'нажмите на выключить для синхронизации панелей';
var SYNCOFFMSG = 'нажмите на включить для синхронизации панелей';