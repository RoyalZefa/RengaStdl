var example_of_style_template_creation =
[
    [ "Шаблон стиля газовой плиты", "gas_stove.html", [
      [ "Техническое задание", "gas_stove.html#autotoc_md25", null ],
      [ "Описание параметров и портов", "gas_stove.html#autotoc_md26", null ],
      [ "Скрипт", "gas_stove.html#autotoc_md27", [
        [ "Получение параметров и объявление переменных", "gas_stove.html#autotoc_md28", null ],
        [ "Создание модели газовой плиты", "gas_stove.html#autotoc_md29", [
          [ "Создание символа дверцы и определение его положения", "gas_stove.html#autotoc_md30", null ],
          [ "Создание символа варочной панели и определение его положения", "gas_stove.html#CookingSurfaceSymbol", null ],
          [ "Создание детальной геометрии", "gas_stove.html#autotoc_md31", null ]
        ] ],
        [ "Создание условного отображения газовой плиты", "gas_stove.html#autotoc_md32", null ],
        [ "Работа с портом", "gas_stove.html#autotoc_md33", null ]
      ] ]
    ] ],
    [ "Шаблон стиля арматурной сетки", "reinforcing_mesh.html", [
      [ "Техническое задание", "reinforcing_mesh.html#autotoc_md34", null ],
      [ "Описание параметров", "reinforcing_mesh.html#autotoc_md35", null ],
      [ "Скрипт", "reinforcing_mesh.html#autotoc_md36", [
        [ "Получение параметров и объявление переменных", "reinforcing_mesh.html#autotoc_md37", null ],
        [ "Создание модели арматурной сетки", "reinforcing_mesh.html#autotoc_md38", null ],
        [ "Создание условного отображения арматурной сетки", "reinforcing_mesh.html#autotoc_md39", null ]
      ] ]
    ] ]
];