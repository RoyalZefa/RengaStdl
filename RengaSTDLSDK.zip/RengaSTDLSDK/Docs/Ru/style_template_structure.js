var style_template_structure =
[
    [ "Шаблоны стилей объектов инженерных систем", "engineering_system_object.html", [
      [ "Файл описания параметров", "engineering_system_object.html#autotoc_md7", [
        [ "Параметры", "engineering_system_object.html#autotoc_md8", null ],
        [ "Порты", "engineering_system_object.html#ports", null ]
      ] ],
      [ "Файлы скриптов", "engineering_system_object.html#autotoc_md9", [
        [ "Получение параметров", "engineering_system_object.html#autotoc_md10", null ],
        [ "Детальная геометрия", "engineering_system_object.html#autotoc_md11", null ],
        [ "Символьная геометрия", "engineering_system_object.html#autotoc_md12", null ],
        [ "Условная геометрия", "engineering_system_object.html#autotoc_md13", null ],
        [ "Остов изоляции", "engineering_system_object.html#insulation", null ],
        [ "Порты", "engineering_system_object.html#autotoc_md14", null ]
      ] ]
    ] ],
    [ "Шаблоны стилей арматурных изделий", "reinforcement.html", [
      [ "Файл описания параметров", "reinforcement.html#autotoc_md15", null ],
      [ "Файлы скриптов", "reinforcement.html#autotoc_md16", [
        [ "Получение параметров", "reinforcement.html#autotoc_md17", null ],
        [ "Получение стиля арматурного стержня и его параметров", "reinforcement.html#autotoc_md18", null ],
        [ "Описание арматурных стержней", "reinforcement.html#autotoc_md19", null ],
        [ "Условная геометрия", "reinforcement.html#autotoc_md20", null ]
      ] ]
    ] ]
];