var style_template_structure =
[
    [ "Style Templates of Engineering System Objects", "engineering_system_object.html", [
      [ "Parameters Description File", "engineering_system_object.html#autotoc_md7", [
        [ "Parameters", "engineering_system_object.html#autotoc_md8", null ],
        [ "Ports", "engineering_system_object.html#ports", null ]
      ] ],
      [ "Script File", "engineering_system_object.html#autotoc_md9", [
        [ "Parameters", "engineering_system_object.html#autotoc_md10", null ],
        [ "Detailed Geometry", "engineering_system_object.html#autotoc_md11", null ],
        [ "Symbol Geometry", "engineering_system_object.html#autotoc_md12", null ],
        [ "Symbolic Geometry", "engineering_system_object.html#autotoc_md13", null ],
        [ "Insulation Skeleton", "engineering_system_object.html#insulation", null ],
        [ "Ports", "engineering_system_object.html#autotoc_md14", null ]
      ] ]
    ] ],
    [ "Style Templates of Reinforcement Units", "reinforcement.html", [
      [ "Parameters Description File", "reinforcement.html#autotoc_md15", [
        [ "Parameters", "reinforcement.html#autotoc_md16", null ]
      ] ],
      [ "Script File", "reinforcement.html#autotoc_md17", [
        [ "Parameters", "reinforcement.html#autotoc_md18", null ],
        [ "Getting the rebar style and its parameters", "reinforcement.html#autotoc_md19", null ],
        [ "Rebar Description", "reinforcement.html#autotoc_md20", null ],
        [ "Symbolic Geometry", "reinforcement.html#autotoc_md21", null ]
      ] ]
    ] ]
];