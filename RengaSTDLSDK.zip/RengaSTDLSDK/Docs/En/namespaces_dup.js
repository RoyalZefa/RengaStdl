var namespaces_dup =
[
    [ "Project", "namespace_project.html", [
      [ "GetRebarStyle", "namespace_project.html#a8afaa603a46296ecb4ba8bff536b1dcc", null ]
    ] ],
    [ "Style", "namespace_style.html", [
      [ "AddRebar", "namespace_style.html#ae656cad8de45eb0d537f8feb627200c0", null ],
      [ "AddRebarSet", "namespace_style.html#a0a3977da03856e39cb5de3bfc4d8b3f8", null ],
      [ "GetParameter", "namespace_style.html#a226a31becef665472bc24b72d7e9404b", null ],
      [ "GetParameterGroup", "namespace_style.html#ad87e24dde8e1970630f3f339967e98ae", null ],
      [ "GetParameterValues", "namespace_style.html#a5de9bf781546993c4acd55a4cb9f5971", null ],
      [ "GetPort", "namespace_style.html#a0225c3f35c71e64ce37e9be4e404c5b0", null ],
      [ "SetDetailedGeometry", "namespace_style.html#a6fd9864bbdaa9f2596dee4d0e6ff5161", null ],
      [ "SetInsulationSkeleton", "namespace_style.html#a8cdce841183e905870ca5c2f0d408033", null ],
      [ "SetSymbolGeometry", "namespace_style.html#a7e23123377607f9ac635d74dc83ba7fb", null ],
      [ "SetSymbolicGeometry", "namespace_style.html#a24c229932e1eddf052a74752ead44f62", null ]
    ] ]
];