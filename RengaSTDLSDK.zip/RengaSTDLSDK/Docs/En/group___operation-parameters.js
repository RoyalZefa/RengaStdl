var group___operation_parameters =
[
    [ "EvolutionParameters", "struct_evolution_parameters.html", [
      [ "EvolutionParameters", "struct_evolution_parameters.html#acdc6d480f5b56d37f0c70285d6292381", null ],
      [ "InwardOffset", "struct_evolution_parameters.html#a6bb2bfc05ee14d03147c7cb94a25374e", null ],
      [ "OutwardOffset", "struct_evolution_parameters.html#a474226f5d6e52d295b8db590803fc254", null ]
    ] ],
    [ "ExtrusionParameters", "struct_extrusion_parameters.html", [
      [ "ExtrusionParameters", "struct_extrusion_parameters.html#a1c071b39d4fc1c217f54aa8bfd354775", null ],
      [ "Direction", "struct_extrusion_parameters.html#a89233ea17561651573bdf9cb3712622c", null ],
      [ "ForwardDirectionDepth", "struct_extrusion_parameters.html#a7bfaaa1acf412451d44c0d65c4ab8f3f", null ],
      [ "ForwardDirectionDraftAngle", "struct_extrusion_parameters.html#a68cf0c8ba8d6c952538c51cc4059233e", null ],
      [ "InwardOffset", "struct_extrusion_parameters.html#a0fffd4d41dbc4e477bdef515f16703c7", null ],
      [ "OutwardOffset", "struct_extrusion_parameters.html#afa3bdd1222e63415c096f4390e2f5deb", null ],
      [ "ReverseDirectionDepth", "struct_extrusion_parameters.html#a8c46f7957edfe287458a4d54934e876a", null ],
      [ "ReverseDirectionDraftAngle", "struct_extrusion_parameters.html#afc49751567cfa986ae1ff8e838c0a06c", null ]
    ] ],
    [ "LoftParameters", "struct_loft_parameters.html", [
      [ "LoftParameters", "struct_loft_parameters.html#a5eedde4555a2e20591bd839be2dc2d09", null ],
      [ "ControlPoints", "struct_loft_parameters.html#aeb1a94714cef99e19adde8070071dde9", null ],
      [ "GuideCurve", "struct_loft_parameters.html#ae1faa197de8c2de072e955f12da3c13f", null ],
      [ "InwardOffset", "struct_loft_parameters.html#a6b363e46f46544dc8f605048cc7d9053", null ],
      [ "OutwardOffset", "struct_loft_parameters.html#ab202e8af8f6cc8720ac03f92aff224b7", null ]
    ] ],
    [ "RevolutionParameters", "struct_revolution_parameters.html", [
      [ "RevolutionParameters", "struct_revolution_parameters.html#a3dda887e851b6c00731b650b72ed4a3c", null ],
      [ "ClockwiseRotationAngle", "struct_revolution_parameters.html#ad11babcbf1fbaf7a7be443fa65612a39", null ],
      [ "CounterClockwiseRotationAngle", "struct_revolution_parameters.html#a47fedf72e32d095523b993178345b55e", null ],
      [ "InwardOffset", "struct_revolution_parameters.html#ac6a42fcc069b54857901995e0bc13b30", null ],
      [ "OutwardOffset", "struct_revolution_parameters.html#a9b52485acc9e063024d1be5659fb9978", null ]
    ] ]
];