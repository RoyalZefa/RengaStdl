var group___two_dimensional =
[
    [ "CircularProfile", "struct_circular_profile.html", [
      [ "CircularProfile", "struct_circular_profile.html#a8899b780ed16f6100fd33a8ef9bb5ed4", null ],
      [ "Diameter", "struct_circular_profile.html#aa9d9194c625afa8d3dd292afc0e0781c", null ]
    ] ],
    [ "RectangularProfile", "struct_rectangular_profile.html", [
      [ "RectangularProfile", "struct_rectangular_profile.html#a831a71bf1b7bd52198c9336ed2423855", null ],
      [ "Height", "struct_rectangular_profile.html#ae9959d5650733711b6c3bcd890443549", null ],
      [ "Width", "struct_rectangular_profile.html#ab6c59665f36cc22ea661bca0c5647d64", null ]
    ] ],
    [ "BoundingRect", "class_bounding_rect.html", [
      [ "BoundingRect", "class_bounding_rect.html#aa66ca7a70f742378916337955dbab29d", null ],
      [ "GetCenter", "class_bounding_rect.html#ac94a620c2486857ce0457a3ce341d4fc", null ],
      [ "GetHeight", "class_bounding_rect.html#a8feafb6d1195a83dee92b580e9060399", null ],
      [ "GetMaxX", "class_bounding_rect.html#a9afb009bd854766ae579ee0dcaa2af4e", null ],
      [ "GetMaxY", "class_bounding_rect.html#afbe9703495d89f991639d16aa571a2b5", null ],
      [ "GetMinX", "class_bounding_rect.html#a7307dad647a5e23c1843bcaf7054a293", null ],
      [ "GetMinY", "class_bounding_rect.html#a564e8d606b458fc46f247c9a11915528", null ],
      [ "GetWidth", "class_bounding_rect.html#a2347089f3545fc993081f5f2463c4a9e", null ]
    ] ],
    [ "Curve2D", "class_curve2_d.html", [
      [ "Clone", "class_curve2_d.html#a8da53dc6e0181594ac26f0b54e19e66d", null ],
      [ "GetBounds", "class_curve2_d.html#a9034902af383f4bcd0c41800a508cc40", null ],
      [ "GetEndPoint", "class_curve2_d.html#a0e5435bcc1fc5d63cb0b1764c1720ec2", null ],
      [ "GetStartPoint", "class_curve2_d.html#a21c5ef1b295fb8ee71cf18642eeab3bb", null ],
      [ "Invert", "class_curve2_d.html#a1a97b142018ccc2d8394edff9b001456", null ],
      [ "operator==", "class_curve2_d.html#a051f5d2fc0e01b833be955c4a07e50ea", null ],
      [ "operator~=", "class_curve2_d.html#a471be98c4856165eddf0d6910e9bbe55", null ],
      [ "Rotate", "class_curve2_d.html#a816450519e86ac7fdc6ce54540179224", null ],
      [ "Scale", "class_curve2_d.html#a1110a64a9602b2a8bbc1240bd732346d", null ],
      [ "Shift", "class_curve2_d.html#ab513731e37d3e84b17c0555eef8a562b", null ],
      [ "Transform", "class_curve2_d.html#a0bae10be8b3af47ffea5f865dd369a0d", null ],
      [ "Trim", "class_curve2_d.html#aa9d5e0f9be2e61cda258e9efd56bed3f", null ]
    ] ],
    [ "FillArea", "class_fill_area.html", [
      [ "FillArea", "class_fill_area.html#a7816dfc0e0efed7d0eb59b0aea352612", null ],
      [ "Clone", "class_fill_area.html#acf8d0acfa1be899dd93beb2359a8d777", null ],
      [ "GetInnerBoundaries", "class_fill_area.html#a4adcd7e86c3ef6326d97f0183725d13c", null ],
      [ "GetOuterBoundary", "class_fill_area.html#a9037ad3bd0e432489b9898d12fbce96c", null ],
      [ "operator==", "class_fill_area.html#a3afe11bf184a218d0e204d8faa2d22aa", null ],
      [ "operator~=", "class_fill_area.html#a69f9a8bcda740e1c387d6c04988a881c", null ],
      [ "Rotate", "class_fill_area.html#a816450519e86ac7fdc6ce54540179224", null ],
      [ "Scale", "class_fill_area.html#a1110a64a9602b2a8bbc1240bd732346d", null ],
      [ "Shift", "class_fill_area.html#a8b55be133976cdf69c4eb467c40e2932", null ],
      [ "Transform", "class_fill_area.html#a0bae10be8b3af47ffea5f865dd369a0d", null ]
    ] ],
    [ "GeometrySet2D", "class_geometry_set2_d.html", [
      [ "GeometrySet2D", "class_geometry_set2_d.html#a0d46df4c8fc941d3f62fe248313e1b99", null ],
      [ "AddCurve", "class_geometry_set2_d.html#a22e8464b4e28ab14f286ba811c3f1581", null ],
      [ "AddLineColorSolidArea", "class_geometry_set2_d.html#aae6a7544bc14aa13b59142ed3d17e197", null ],
      [ "AddMaterialColorSolidArea", "class_geometry_set2_d.html#ad6dc911ad0373bc6ddcff40ee2e0b8c2", null ],
      [ "Clone", "class_geometry_set2_d.html#aad84d01fd4ecf34e82f7822ae838e40e", null ],
      [ "operator==", "class_geometry_set2_d.html#a46391cb635ec98e429a695d6f8b00f75", null ],
      [ "operator~=", "class_geometry_set2_d.html#a9a0edecab97416b0b62455c8a722b8f8", null ],
      [ "Rotate", "class_geometry_set2_d.html#a816450519e86ac7fdc6ce54540179224", null ],
      [ "Scale", "class_geometry_set2_d.html#a9a437f6c1ccedfdc54db496d254f4755", null ],
      [ "Shift", "class_geometry_set2_d.html#a8b55be133976cdf69c4eb467c40e2932", null ],
      [ "Transform", "class_geometry_set2_d.html#a0bae10be8b3af47ffea5f865dd369a0d", null ]
    ] ],
    [ "Matrix2D", "class_matrix2_d.html", [
      [ "Matrix2D", "class_matrix2_d.html#ae7cc9ba393cad7f1a399618715b99bcf", null ],
      [ "Clone", "class_matrix2_d.html#a4a9fa5cc43063a00c2c47a90179d8088", null ],
      [ "Invert", "class_matrix2_d.html#a1a97b142018ccc2d8394edff9b001456", null ],
      [ "operator==", "class_matrix2_d.html#af362cfeb60b759ac84b0a00dfe8f0a2c", null ],
      [ "operator~=", "class_matrix2_d.html#a3b91acf095c2c7b83f76bc7d7ce863e0", null ],
      [ "Rotate", "class_matrix2_d.html#a816450519e86ac7fdc6ce54540179224", null ],
      [ "Scale", "class_matrix2_d.html#a1110a64a9602b2a8bbc1240bd732346d", null ],
      [ "Shift", "class_matrix2_d.html#a8b55be133976cdf69c4eb467c40e2932", null ],
      [ "Transform", "class_matrix2_d.html#a0bae10be8b3af47ffea5f865dd369a0d", null ]
    ] ],
    [ "Point2D", "class_point2_d.html", [
      [ "Point2D", "class_point2_d.html#abc5098d344e64999833af4fcda0d7966", null ],
      [ "Clone", "class_point2_d.html#a942afe80d196163e310cf80f92401bbc", null ],
      [ "GetX", "class_point2_d.html#a3d5460814499e3a4c63001b7cb4277d3", null ],
      [ "GetY", "class_point2_d.html#a2a0e2103d147d4c3219d7480dbe60c73", null ],
      [ "operator==", "class_point2_d.html#ab99a26d295f88a5109373d5361ec55b2", null ],
      [ "operator~=", "class_point2_d.html#a7ad9ffdffc0810a8597002d6354b0a0f", null ],
      [ "Rotate", "class_point2_d.html#a816450519e86ac7fdc6ce54540179224", null ],
      [ "Scale", "class_point2_d.html#a2d52d9e3723252e8ba0367eff1bbb5d6", null ],
      [ "Shift", "class_point2_d.html#a8b55be133976cdf69c4eb467c40e2932", null ],
      [ "Transform", "class_point2_d.html#a0bae10be8b3af47ffea5f865dd369a0d", null ]
    ] ],
    [ "CoordinateSystem2D", "group___two-dimensional.html#gaa0ef7ea054c4725fe01aa96594d57bea", [
      [ "Cartesian", "group___two-dimensional.html#ggaa0ef7ea054c4725fe01aa96594d57beaaee69cb7798900c68e7ce6a21b3b022dc", null ],
      [ "Polar", "group___two-dimensional.html#ggaa0ef7ea054c4725fe01aa96594d57beaa51f76399f41548c0b34986de388a0146", null ]
    ] ],
    [ "ClipCurvesByRegions", "group___two-dimensional.html#gaab8e11e2822f50945892bafa05b61028", null ],
    [ "CreateArc2DByCenterStartEndPoints", "group___two-dimensional.html#ga7f326a5265f5d31f5074777e80a9cf1d", null ],
    [ "CreateArc2DByThreePoints", "group___two-dimensional.html#ga9d6e956b31abfe2d59cbc84064a20e17", null ],
    [ "CreateCircle2D", "group___two-dimensional.html#gab1466429a5ecfbb62632bcfa69ccaaa1", null ],
    [ "CreateCompositeCurve2D", "group___two-dimensional.html#gae41bb7f15bb63deeba3e99c793d54885", null ],
    [ "CreateEllipse2D", "group___two-dimensional.html#gaed608dd82de7de02b3e050084b0a87c9", null ],
    [ "CreateEllipticalArc2DByCenterStartEndPoints", "group___two-dimensional.html#gab3b73abae5cb2ed824aef10d00be5132", null ],
    [ "CreateLineSegment2D", "group___two-dimensional.html#gacc012aeef5eb50df053a90ab7422796c", null ],
    [ "CreateParametricCurve2D", "group___two-dimensional.html#ga59d0fda66e5a0dffc336db61fd7952d2", null ],
    [ "CreatePolyline2D", "group___two-dimensional.html#gaa6028e40b07136091c3c42928a8e6edc", null ],
    [ "CreateRectangle2D", "group___two-dimensional.html#ga85de401e4b06838cce3df4f2ee83ca25", null ],
    [ "FilletCornerAfterSegment2D", "group___two-dimensional.html#gae88452d7481d6ca9ee8b33147b0f40c8", null ],
    [ "FilletCorners2D", "group___two-dimensional.html#ga249b3d5c16a0d819242e79c3b751f23d", null ],
    [ "IntersectCurves2D", "group___two-dimensional.html#ga95e32913b65f08035ecc21946be94f2e", null ]
];