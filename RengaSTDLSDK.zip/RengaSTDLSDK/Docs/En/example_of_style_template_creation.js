var example_of_style_template_creation =
[
    [ "Style Template of Gas Stove", "gas_stove.html", [
      [ "Technical Task", "gas_stove.html#autotoc_md26", null ],
      [ "Description of parameters and ports", "gas_stove.html#autotoc_md27", null ],
      [ "Script", "gas_stove.html#autotoc_md28", [
        [ "Getting parameters and declaring variables", "gas_stove.html#autotoc_md29", null ],
        [ "Creating a gas stove model", "gas_stove.html#autotoc_md30", [
          [ "Creating a door symbol and setting its position", "gas_stove.html#autotoc_md31", null ],
          [ "Creating a cooking surface symbol and setting its position", "gas_stove.html#CookingSurfaceSymbol", null ],
          [ "Creating a detailed geometry", "gas_stove.html#autotoc_md32", null ]
        ] ],
        [ "Creating a symbolic representation of a gas stove", "gas_stove.html#autotoc_md33", null ],
        [ "Working with a port", "gas_stove.html#autotoc_md34", null ]
      ] ]
    ] ],
    [ "Reinforcing Mesh Style Template", "reinforcing_mesh.html", [
      [ "Technical Task", "reinforcing_mesh.html#autotoc_md35", null ],
      [ "Description of parameters", "reinforcing_mesh.html#autotoc_md36", null ],
      [ "Script", "reinforcing_mesh.html#autotoc_md37", [
        [ "Getting parameters and declaring variables", "reinforcing_mesh.html#autotoc_md38", null ],
        [ "Creating a reinforcing mesh model", "reinforcing_mesh.html#autotoc_md39", null ],
        [ "Creating a symbolic representation of a reinforcing mesh", "reinforcing_mesh.html#autotoc_md40", null ]
      ] ]
    ] ]
];