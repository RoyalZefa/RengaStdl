/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Renga STDL", "index.html", [
    [ "About Renga STDL", "index.html", "index" ],
    [ "Changelog", "changelog.html", [
      [ "Version 3.0", "changelog.html#v3_0", null ],
      [ "Version 2.0", "changelog.html#v2_0", null ],
      [ "Version 1.1", "changelog.html#v1_1", null ],
      [ "Version 1.0", "changelog.html#autotoc_md4", null ]
    ] ],
    [ "Required Tools", "required_tools.html", [
      [ "Code Editor", "required_tools.html#autotoc_md5", null ],
      [ "Style Template Developer Kit", "required_tools.html#autotoc_md6", null ]
    ] ],
    [ "Style Template Structure", "style_template_structure.html", "style_template_structure" ],
    [ "Style Template Building", "style_template_building.html", [
      [ "Command Line Format", "style_template_building.html#autotoc_md22", null ],
      [ "Using RstBuilder", "style_template_building.html#autotoc_md23", [
        [ "Checking Input Files", "style_template_building.html#autotoc_md24", null ]
      ] ],
      [ "Integration in Visual Studio Code", "style_template_building.html#autotoc_md25", null ]
    ] ],
    [ "Examples of How to Create Style Templates", "example_of_style_template_creation.html", "example_of_style_template_creation" ],
    [ "Testing and Debugging", "testing_and_debugging.html", [
      [ "Handling Errors Occurring During Script Execution", "testing_and_debugging.html#autotoc_md41", null ],
      [ "Using the print() Function for Debugging:", "testing_and_debugging.html#autotoc_md42", null ],
      [ "Getting Additional Information with the tostring() Function", "testing_and_debugging.html#autotoc_md43", null ]
    ] ],
    [ "How to create a symbolic expression", "expressions.html", null ],
    [ "Style Template API", "topics.html", "topics" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"changelog.html",
"group___three-dimensional.html#ga724990d0a1c91533f39f870d058993f7"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';