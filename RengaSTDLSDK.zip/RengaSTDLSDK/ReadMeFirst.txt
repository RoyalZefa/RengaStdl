﻿Dear Renga STDLSDK users,

The Renga STDLSDK has the following structure:

\                               - Root SDK directory
|__ \Samples                    - Contains style template samples
|__ \RstBuilder
    |__ RstBuilder.exe          - Console utility for style template building
|__ \Docs                       - Documentation contents
|__ GetStarted_en.html          - Reference for Renga STDL (english)
|__ GetStarted_ru.html          - Reference for Renga STDL (russian)
|__ ReadMeFirst.txt             - This document


Please refer to GetStarted_en.html or GetStarted_ru.html for the detailed description of Renga STDL and instructions on
how to make your own style template for Renga.

If you have any comments or questions, please do not hesitate to contact us (https://sd.ascon.ru/).

Sincerely,
Renga team
